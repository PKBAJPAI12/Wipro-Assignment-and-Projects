﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MiniMovie
{
    class Theatre
    {
       public  string TheatreName;
       public string TheatrePlace;
        public Theatre(string TheatreName,string TheatrePlace)
        {
            this.TheatreName = TheatreName;
            this.TheatrePlace = TheatrePlace;
        }
    }
}
