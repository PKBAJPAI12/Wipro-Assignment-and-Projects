﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MiniMovie
{
    class Booking
    {
        public int Ticket;
        public Booking(int ti)
        {
            Ticket = ti;
        }
    }
}
