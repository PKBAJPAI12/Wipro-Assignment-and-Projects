﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MiniMovie
{
    class Movie
    {
        public string  Moviename;
        public Movie(string mo)
        {
            Moviename = mo;


        }
    }
}
