using System;


class Program
{
    public static void Main(String[] args)
    {
        string s = @"D:\ok\vineet";
        File.Create(s).Close();
        List<string> l = new List<string>();
        l.Add("hello");
        l.Add("my");
        l.Add("name");
        l.Add("is");
        l.Add("vineet");
        File.WriteAllLines(s, l);
        var i=File.ReadAllLines(s);
        foreach(string b in i)
        {
            Console.Write(b);
        }
        
        

        

    }


}


