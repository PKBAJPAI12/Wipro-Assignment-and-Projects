using System;
using System.Collections;
using System.ComponentModel.DataAnnotations;

class Program
{
    public static void Main(String[] args)
    {
        Program<string> p = new Program<string>("ijjh243i4h432h4ui324h");
        p.find();
        

    }

}
public class Program<T1>
{
    T1 str;
    List<char> alpha;
    List<char> digit;

    public Program(T1 str)
    {
        this.str = str;
        alpha = new List<char>();
        digit = new List<char>();
    }
    public void find()
    {
        string st = "";
        
        foreach(char ch in (string)(object)str)
        {
            if(Char.IsDigit(ch))
            {
                alpha.Add(ch);
            }
            else if(Char.IsLetter(ch))
            {
                digit.Add(ch);
            }
        }
        alpha.Sort();
        digit.Sort();
        foreach(char ch in alpha)
        {
            Console.Write(ch+" ");
        }
        Console.WriteLine();
        foreach(char ch in digit)
        {
            Console.Write(ch+" ");
        }
    }
    

}


