using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using CsvHelper;


class Program
{
    public static void Main(String[] args)
    {
        string k = @"D:\visual\aaaa.csv";
        File.Create(k).Close();
        EmployeeData e = new EmployeeData();
        e.employeeinfo.Add(new Employee(1, "ramesh", "senior", DateTime.Parse("02/02/2001"), "full stack"));
        e.employeeinfo.Add(new Employee(2, "ramesh", "senior", DateTime.Parse("02-02-2001"), "full stack"));
        e.employeeinfo.Add(new Employee(3, "ramesh", "senior", DateTime.Parse("02-02-2001"), "full stack"));
        e.employeeinfo.Add(new Employee(4, "ramesh", "senior", DateTime.Parse("02-02-2001"), "full stack"));
        e.employeeinfo.Add(new Employee(5, "ramesh", "senior", DateTime.Parse("02-02-2001"), "full stack"));
        for (int i = 0; i < e.employeeinfo.Count; i++)
        {
            using (StreamWriter writer = new StreamWriter(k, append: true))
            {
                writer.Write(e.employeeinfo[i].EmployeeId + ",");

                writer.Write(e.employeeinfo[i].DepartmentName+",");
                writer.Write(e.employeeinfo[i].Designation+",");
                writer.Write(e.employeeinfo[i].JoiningDate+",");
                writer.WriteLine(e.employeeinfo[i].EmployeeName);
                writer.Close();
            }
        }


    }
    




}


public class Employee
{
    public int EmployeeId { get; set; }
    public string EmployeeName { get; set; }
    public string Designation { get; set; }
    public DateTime JoiningDate { get; set; }
    public string DepartmentName { get; set; }
    public Employee( int EmployeeId, string EmployeeName,string Designation,DateTime JoiningDate,string DepartmentName)
    {
        this.EmployeeId = EmployeeId;
        this.EmployeeName = EmployeeName;       
        this.Designation = Designation; 
        this.JoiningDate = JoiningDate; 
        this.DepartmentName = DepartmentName;   
    }
}
class EmployeeData
{
    public List<Employee> employeeinfo{ get; set; }

    public EmployeeData()
    {
        employeeinfo = new List<Employee>();
    }

}


