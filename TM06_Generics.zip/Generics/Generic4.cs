using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using CsvHelper;


class Program
{
    public static void Main(String[] args)
    {
        TicketManager t = new TicketManager();
        t.GenerateServiceToken("front",DateTime.Parse("13-02-2001 10:45:34"),"seat full");
        t.GenerateServiceToken("back", DateTime.Parse("13-02-2001 23:12:23"), "seat full");
        t.GenerateServiceToken("front", DateTime.Parse("13-02-2001 11:12:23"), "no seats");
        t.GenerateServiceToken("middle", DateTime.Parse("13-02-2001 3:3:3"), "seat full");
        t.GenerateServiceToken("front", DateTime.Parse("13-03-2001 3:13:53"), "seat full");
        t.GenerateServiceToken("back", DateTime.Now, "seat vacant");
        t.GenerateServiceToken("front", DateTime.Parse("13-02-2001 13:23:30"), "under maintainance");
        Console.WriteLine("****************************************TOKEN MANAGEMENT SYSTEM****************************************");
        while (true)
        {

            Console.WriteLine("Select One Option");
            Console.WriteLine("1.  Create Token");
            Console.WriteLine("2.  Get Next Token");
            Console.WriteLine("3.  Update Token");
            Console.WriteLine("4.  Skip Token");
            Console.WriteLine("5.  List All Token");
            Console.WriteLine("6.  Exit");
            int h = int.Parse(Console.ReadLine());
            if (h == 1)
            {
                Console.WriteLine("enter position");
                string position = Console.ReadLine();
                Console.WriteLine("enter ticket date time");
                DateTime dateTime = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("enter status");
                string status = Console.ReadLine();
                t.GenerateServiceToken(position, dateTime, status);
            }
            else if (h == 2)
            {
                t.GetNextToken();
            }
            else if (h == 3)
            {
                Console.WriteLine("enter updated id");
                int g = int.Parse(Console.ReadLine());
                t.updatetoken(g);
            }
            else if (h == 4)
            {
                ServiceToken k = t.skiptoken();
                Console.WriteLine("token id = " + k.tokenid + "  position = " + k.position + "  ticket date and time = " + k.ticketdatetime + "  status = " + k.status);
            }
            else if (h == 5)
            {
                t.display();
            }
            else if (h == 6)
            {
                return;
            }
        }

    }
    
}
class TicketManager
{
    public Queue<ServiceToken> q { get; set; }

    public TicketManager()
    {
        q = new Queue<ServiceToken>();
    }
    public void GenerateServiceToken(string position,DateTime dateTime,string status)
    {
        ServiceToken a = new ServiceToken(position, dateTime, status);
        
            q.Enqueue(a);
    }
    public void GetNextToken()
    {
        try
        {
            ServiceToken k = q.Peek();
            Console.WriteLine("token id = " + k.tokenid + "  position = " + k.position + "  ticket date and time = " + k.ticketdatetime + "  status = " + k.status);

        }
        catch(Exception e)
        {
            Console.WriteLine("no data to show");
        }
        }
    public void updatetoken(int id)
    {
        if(q.Count>0)
        {
            q.Peek().tokenid = id;
        }
        else
        {
            Console.WriteLine("empty data there is no element to update");
        }
        
    }
    public ServiceToken skiptoken()
    {
        q.Dequeue();
        return q.Peek();
    }
    public void display()
    {
        while(q.Count>0)
        {
            ServiceToken k = q.Dequeue();
            Console.WriteLine("token id = " + k.tokenid + "  position = " + k.position + "  ticket date and time = " + k.ticketdatetime + "  status = " + k.status); 
        }
    }

}
class ServiceToken
{
    int k = 0;
    static int i = 0;
    
    public int tokenid
    {
        
        get
        {
            return k;
        }
        set
        {
            k = value;
        }
        
    }
    
    public string position { get; set; }
    public DateTime ticketdatetime { get; set; }
    public string status { get; set; }

    public ServiceToken(string position, DateTime ticketdatetime, string status)
    {
        ++i;
        k = i;
        this.position = position;
        this.ticketdatetime = ticketdatetime;
        this.status = status;
    }

}




