using System;
using System.Collections;
using System.ComponentModel.DataAnnotations;

class Program
{
    public static void Main(String[] args)
    {
        EmployeeDal<Employee> d = new EmployeeDal<Employee>();
        
        
        d.AddEmployee(new Employee("lovesh", 5, 1200));
        d.AddEmployee(new Employee("vineet", 4, 1200));
        d.AddEmployee(new Employee("puneet", 3, 1200));
        d.AddEmployee(new Employee("sumit", 2, 1200));
        d.AddEmployee(new Employee("lumit", 1, 1200));
        d.AddEmployee(new Employee("gaurav", 6, 1200));
        d.DeleteEmployee(3);
        Console.WriteLine(d.SearchEmployee(6));
        d.sorting();
        Employee[] b = d.GetAllEmployeesListAll();
        foreach(Employee e in b)
        {
            Console.WriteLine("id " + e.employeeid + "  name " + e.employeename + "  salary " + e.salary);
        }
        


    }

}
public class Employee
{

    public string employeename;

    [Key]
    public int employeeid;
    public double salary;

    public Employee(string employeename, int employeeid, double salary)
    {
        this.employeename = employeename;
        this.employeeid = employeeid;
        this.salary = salary;
    }

}
public class EmployeeDal<T1>
{
    ArrayList a = new ArrayList();

   


    public bool AddEmployee(T1 e)
    {
        
        a.Add(e);
        return true;
    }
    public bool DeleteEmployee(int id)
    {
        int i = 0;
        while (i < a.Count)
        {
            Employee k = (Employee)a[i];
            if (k.employeeid==id)
            {
                a.RemoveAt(i);
                break;
            }
            i++;
        }
        return true;
    }
    public string SearchEmployee(int id)
    {
        int i = 0;
        string k="employee not found";
        while(i<a.Count)
        {
            Employee e = (Employee)a[i];
            if(e.employeeid==id)
            {
                k= e.employeename;
                break;
            }
            i++;
        }
        return k;

    }
    public void sorting()
    {
        a.Sort(new Comparer());
    }
    public Employee[] GetAllEmployeesListAll()
    {
        Employee[] employees = new Employee[a.Count];
        for(int i=0;i<a.Count;i++)
        {
            employees[i]=(Employee)a[i];
        }
        return employees;
    }

}
public class Comparer:IComparer
{
    int IComparer.Compare(object x,object y)
    {
        Employee xx = (Employee)x;
        Employee yy = (Employee)y;
        return xx.employeeid.CompareTo(yy.employeeid);    
    
        
    }
}


